// JavaScript Document
//搜索热门关键字代码
function fbbox(fbboxID,ObjID){
	$(fbboxID).click(function(){
		$(ObjID).show();
	});
	$(ObjID).hover('',function(){
		$(ObjID).hide();
	});
	$(fbboxID).keydown(function(){
		$(ObjID).hide();
	});
	$(ObjID).find('li').click(function(){
		//var text = $(this).find('h1').text();
		$(ObjID).hide();
	});
}
fbbox('#search-keyword','#hotwords');
//搜索框检测代码
/*在下面函数编辑模糊查询*/
function submitFn(obj, evt){
    value = $(obj).find('.keyword').val().trim();
    if(!value.length){
        window.alert("查询内容不能为空!!!")
    }
    else{
        // _html = "你刚刚输入的内容是: ";
        // _html += "<b>" + value + "</b>";
        return  url( 'request' )
    }

    $(obj).find('.result-container').html('<span>' + _html + '</span>');
    $(obj).find('.result-container').fadeIn(100);

    evt.preventDefault();
}