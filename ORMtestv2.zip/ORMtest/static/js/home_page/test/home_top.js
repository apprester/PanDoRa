	$("#ch>li").click(function (e) {
		if ($(this).val()==1){
		    $("#inpu").attr("value","综艺").removeClass("keyword").css("width"," 350px");
			$("#ch>li").removeClass("li-style");
			$("#li-1").addClass("li-style");
			$("#show-submit").removeClass("hidden");
		}else if ($(this).val()==2){
		    $("#inpu").attr("value","小说").removeClass("keyword").css("width"," 350px");
		    $("#ch>li").removeClass("li-style");
			$("#li-2").addClass("li-style");
            $("#show-submit").removeClass("hidden");
		}else if ($(this).val()==3){
		    $("#inpu").attr("value","电影").removeClass("keyword").css("width"," 350px");
			$("#ch>li").removeClass("li-style");
			$("#li-3").addClass("li-style");
			$("#show-submit").removeClass("hidden");
		}else if ($(this).val()==4){
		    $("#inpu").attr("value","电视剧").removeClass("keyword").css("width"," 350px");
			$("#ch>li").removeClass("li-style");
			$("#li-4").addClass("li-style");
			$("#show-submit").removeClass("hidden");
		}else if ($(this).val()==5){
		    $("#inpu").attr("value","书籍").removeClass("keyword").css("width"," 350px");
			$("#ch>li").removeClass("li-style");
			$("#li-5").addClass("li-style");
			$("#show-submit").removeClass("hidden");
		}else if ($(this).val()==6){
		    $("#inpu").attr("value","音乐").removeClass("keyword").css("width"," 350px");
			$("#ch>li").removeClass("li-style");
			$("#li-6").addClass("li-style");
			$("#show-submit").removeClass("hidden");
		}
	  });