    function IEVersion() { //解决IE浏览器尺寸不对的情况。
        var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
        var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
        var isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
        var isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
        if(isIE) {
            var reIE = new RegExp("MSIE (\\d+\\.\\d+);");
            reIE.test(userAgent);
            var fIEVersion = parseFloat(RegExp["$1"]);
        if(fIEVersion == 7) {
            alert("7");
        } else if(fIEVersion == 8) {
            alert("8");
        } else if(fIEVersion == 9) {
            alert("9");
        } else if(fIEVersion == 10) {
            alert("10");
        } else {
            alert("6");//IE版本<=7
        }
        } else if(isEdge) {
            alert("0");//edge
    } else if(isIE11) {//IE11
        var linkNode = document.createElement("link"),scriptNode = document.createElement("script");
        linkNode.setAttribute("rel","stylesheet");
        linkNode.setAttribute("type","text/css");
        scriptNode.setAttribute("type", "text/javascript");
        linkNode.setAttribute("href","../static/css/home_page/style_ie.css");
        document.head.appendChild(linkNode);
    }else{//其他浏览器
         var linkNode1 = document.createElement("link"),scriptNode1 = document.createElement("script");
        linkNode1.setAttribute("rel","stylesheet");
        linkNode1.setAttribute("type","text/css");
        scriptNode1.setAttribute("type", "text/javascript");
        linkNode1.setAttribute("href","../static/css/home_page/main_css.css");
        document.head.appendChild(linkNode1);
        }
    }
    IEVersion();