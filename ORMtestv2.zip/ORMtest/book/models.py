from django.db import models

# Create your models here.
# 必须将父类设置为models.Model或者是它的子类。
class resource(models.Model):
    # 各个字段
    id = models.IntegerField(primary_key=True)
    url = models.CharField(max_length=255, null=False)
    filename = models.CharField(max_length=255, default='NULL')
    username = models.CharField(max_length=255, default='NULL')
    fsize = models.FloatField(default='NULL')
    ctime = models.DateTimeField(default='NULL')
    gettime = models.DateTimeField(default='NULL')
    pwd = models.CharField(max_length=8, default='NULL')
    avatar = models.CharField(max_length=255, default='NULL')
    category = models.IntegerField(default=0)
    path = models.CharField(max_length=254, default='NULL')
    shareid = models.IntegerField(default=0)
    uk = models.IntegerField(default=0)
    isdir = models.IntegerField(default=0)
    resume = models.TextField(default='NULL')
    dir_context = models.TextField(default='NULL')
    class Meta:
        ordering = ['-ctime']

# 1.先使用python manage.py makemigrations生成迁移脚本文件
# 2.使用python manage.py migrate 将新生成的迁移脚本文件映射到数据库中
# SQL中的like在课程38 ： iexact但没有%
# contain（大小写敏感），icontain（大小写不敏感）前后就有%，
# projects.filter查询满足条件的输出，projects.exclude过滤满足条件的记录 43
# 排序projects.order_by('name')正序，projects.order_by('-name')倒序,多重指定排序规则order_by('','')
# 可在模型models.py中设置排序，使用ordering = [''],多重指定排序规则['', '']
