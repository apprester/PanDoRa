from django.shortcuts import render
from .models import resource
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render,redirect,reverse
import datetime
import math
result_list = []
# Create your views here.
def index(request):
    #添加记录到数据库
    # resource1 = resource(id=3, url='https://pan.baidu.com/s/16BfyGobo9MeyyQVBFo2WoA',
    #                      filename='Python 3网络爬虫开发实战》.zip',username='不二**是我', size=382051538, time='2019-01-26 10:44:00')
    # resource1.save()
    return render(request, 'home.html')
def index1(request):
    #添加记录到数据库
    # resource1 = resource(id=3, url='https://pan.baidu.com/s/16BfyGobo9MeyyQVBFo2WoA',
    #                      filename='Python 3网络爬虫开发实战》.zip',username='不二**是我', size=382051538, time='2019-01-26 10:44:00')
    # resource1.save()
    return render(request, 'test_form.html')
def getneed(request):
    # 可以采用 needcheck = request.POST.get(表单上面的值如：needcheck)
    if request.method == 'POST' and request.POST.get('needcheck') is not None :
        needcheck = request.POST.get('needcheck')
        print(needcheck)
    elif request.GET.get('needcheck') is not None :
        needcheck = request.GET.get('needcheck')
    resource1 = resource.objects.filter(filename__contains='%s' %needcheck )[:20000]
    # resource1 = resource.objects.all()
    # for i in result_list:
    #     print(i)
    for check_size in resource1:
        # 格式化文件大小, 日期
        kb = 1024
        mb = kb * 1024
        gb = mb * 1024
        tb = gb * 1024
        if check_size.fsize > tb:
            check_size.fsize = '%.2f TB' % float(check_size.fsize / tb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)

        elif tb >= check_size.fsize > gb:
            check_size.fsize = '%.2f GB' % float(check_size.fsize / gb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)

        elif gb >= check_size.fsize > mb:
            check_size.fsize = '%.2f MB' % float(check_size.fsize / mb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)

        elif mb >= check_size.fsize >= kb:
            check_size.fsize = '%.2f KB' % float(check_size.fsize / kb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)
            # return "%.1f KB" % float(check_size / kb)
        else:
            check_size.fsize = '%.2f ' % float(check_size.fsize)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
        # obj_list.append(list1)

    paginator = Paginator(resource1, 10, orphans=2)
    page = request.GET.get('page')
    contacts = paginator.get_page(page)  # 当前页并具有处理超出页码范围的状况,页码不是数字返回第一页，超出返回最后一页

    # 使用了列表生成式，这样可以避免超出页码范围或出现页码数为负数的情况，另外我把page_list页码列表范围传出去，
    # 这样就可以在模板中使用了！另外添加了首尾页以及省略号！之后就是在模板中使用了！
    page_list = [x for x in range(contacts.number - 2, contacts.number + 3) if x in paginator.page_range]
    # 添加省略号
    # 判断当前第一个元素减1是否大于2
    if page_list[0] - 1 >= 2:
        page_list.insert(0, '...')  # 则插入该数组成为第一个元素 ...
    if paginator.num_pages - page_list[-1] >= 2:  # 判断最大页码数-最后一个元素相减是否大于2
        page_list.append('...')  # 则添加一个元素
    # 添加首尾页
    if page_list[0] == '...':
        page_list.insert(0, 1)  # 则插入该数组成为第一个元素（首页）
    if page_list[-1] != paginator.num_pages:  # 判断是否不等于最大页码
        page_list.append(paginator.num_pages)  # 不等于则插入到最后一个元素（尾页）
    context = {'contacts': contacts, 'page_list': page_list,'needcheck': needcheck}
    return render(request, 'result.html', context=context)

def menu(request, menu_id, needcheck_val):
    quick_check = 0
    if menu_id == '1':
        quick_check = 1
    elif menu_id == '2':
        quick_check = 2
    elif menu_id == '3':
        quick_check = 3
    elif menu_id == '4':
        quick_check = 4
    elif menu_id == '5':
        quick_check = 5
    elif menu_id == '6':
        quick_check = 6
    elif menu_id == '7':
        quick_check = 7
    elif menu_id == '0':
        quick_check = 0
    else:
        pass
    resource1 = resource.objects.filter(category=quick_check,filename__contains=needcheck_val)[:20000]
    for check_size in resource1:
        # 格式化文件大小, 日期
        kb = 1024
        mb = kb * 1024
        gb = mb * 1024
        tb = gb * 1024
        if check_size.fsize > tb:
            check_size.fsize = '%.2f TB' % float(check_size.fsize / tb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)

        elif tb >= check_size.fsize > gb:
            check_size.fsize = '%.2f GB' % float(check_size.fsize / gb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)

        elif gb >= check_size.fsize > mb:
            check_size.fsize = '%.2f MB' % float(check_size.fsize / mb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)

        elif mb >= check_size.fsize >= kb:
            check_size.fsize = '%.2f KB' % float(check_size.fsize / kb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)
            # return "%.1f KB" % float(check_size / kb)
        else:
            check_size.fsize = '%.2f ' % float(check_size.fsize)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
    # request.session['resource'] = resource1
    paginator = Paginator(resource1, 10)
    page = request.GET.get('page', 1)  # 当前页面
    contacts = paginator.get_page(page)  # 当前页并具有处理超出页码范围的状况,页码不是数字返回第一页，超出返回最后一页
    # 将模糊查询后的对象resource1以result名字返回到request_test页面

    # 使用了列表生成式，这样可以避免超出页码范围或出现页码数为负数的情况，另外我把page_list页码列表范围传出去，
    # 这样就可以在模板中使用了！另外添加了首尾页以及省略号！之后就是在模板中使用了！
    page_list = [x for x in range(contacts.number - 2, contacts.number + 3) if x in paginator.page_range]
    print(page_list)
    # 添加省略号
    # 判断当前第一个元素减1是否大于2
    if page_list[0] - 1 >= 2:
        page_list.insert(0, "...")  # 则插入该数组成为第一个元素 ...
    if paginator.num_pages - page_list[-1] >= 2:  # 判断最大页码数-最后一个元素相减是否大于2
        page_list.append('...')  # 则添加一个元素
    print(page_list)
    # 添加首尾页
    if page_list[0] == '...':
        page_list.insert(0, 1)  # 则插入该数组成为第一个元素（首页）
    if page_list[-1] != paginator.num_pages:  # 判断是否不等于最大页码
        page_list.append(paginator.num_pages)  # 不等于则插入到最后一个元素（尾页）
    context = {'contacts': contacts, 'page_list': page_list, 'needcheck': needcheck_val, 'menutype':quick_check}
    return render(request, 'result.html', context=context)

def detail_page(request, main_id):
    main_res = resource.objects.filter(pk=main_id)
    # 格式化文件大小,日期
    kb = 1024;
    mb = kb * 1024;
    gb = mb * 1024;
    tb = gb * 1024;
    for check_size in main_res:
        # res_time.append('%s-%s-%s' %(check_size.time.year, check_size.time.month, check_size.time.day))
        if check_size.fsize > tb:
            check_size.fsize = '%.2f TB' % float(check_size.fsize / tb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)

        elif tb >= check_size.fsize > gb:
            check_size.fsize = '%.2f GB' % float(check_size.fsize / gb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)

        elif gb >= check_size.fsize > mb:
            check_size.fsize = '%.2f MB' % float(check_size.fsize / mb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)

        elif mb >= check_size.fsize >= kb:
            check_size.fsize = '%.2f KB' % float(check_size.fsize / kb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            print(check_size.fsize)
            # return "%.1f KB" % float(check_size / kb)
        else:
            check_size.fsize = '%.2f ' % float(check_size.fsize)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
    for main_format in main_res:
        if main_format.isdir == 0:
            context_list=''
        elif main_format.isdir == 1:
            if main_format.dir_context != '[]' :
                context_list = main_format.dir_context[2:-2]
                context_list = context_list.split("', '")
            else:
                context_list=''
        else:
            pass
    return render(request, 'message.html', context={'finally': main_res, 'context_list': context_list})



ONE_PAGE_OF_DATA = 40
def test(request):
    # 可以采用 needcheck = request.POST.get(表单上面的值如：needcheck)
    if request.method == 'POST' and request.POST.get('needcheck') is not None:
        needcheck = request.POST.get('needcheck')
        print(needcheck)
    elif request.GET.get('needcheck') is not None:
        needcheck = request.GET.get('needcheck')


    page = request.GET.get('page')

    try:
        cur_page = int(request.GET.get('page', '1'))
        allPage = int(request.GET.get('allPage', '1'))
        pageType = str(request.GET.get('pageType', ''))
    except ValueError:
        cur_page = 1
        allPage = 1
        pageType = ''
    print(cur_page)
    startPos = (cur_page - 1) * ONE_PAGE_OF_DATA
    print(startPos)
    endPos = startPos + ONE_PAGE_OF_DATA
    print(endPos)
    # resource1 = resource.objects.all()
    # for i in result_list:
    #     print(i)
    resource1 = resource.objects.filter(filename__contains='%s' % needcheck)[startPos:endPos]
    for check_size in resource1:
        # 格式化文件大小, 日期
        kb = 1024
        mb = kb * 1024
        gb = mb * 1024
        tb = gb * 1024
        if check_size.fsize > tb:
            check_size.fsize = '%.2f TB' % float(check_size.fsize / tb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)

        elif tb >= check_size.fsize > gb:
            check_size.fsize = '%.2f GB' % float(check_size.fsize / gb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)

        elif gb >= check_size.fsize > mb:
            check_size.fsize = '%.2f MB' % float(check_size.fsize / mb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)

        elif mb >= check_size.fsize >= kb:
            check_size.fsize = '%.2f KB' % float(check_size.fsize / kb)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
            # print(check_size.fsize)
            # return "%.1f KB" % float(check_size / kb)
        else:
            check_size.fsize = '%.2f ' % float(check_size.fsize)
            check_size.ctime = '%s-%s-%s' % (check_size.ctime.year, check_size.ctime.month, check_size.ctime.day)
        # obj_list.append(list1)

    posts = resource.objects.filter(filename__contains='%s' % needcheck)[startPos:endPos]
        # 判断点击了【下一页】还是【上一页】
    if pageType == 'pageDown':
            cur_page += 1
    elif pageType == 'pageUp':
            cur_page -= 1

    if cur_page == 1 and allPage == 1:  # 标记1
            allPostCounts = resource1.objects.count()
            allPage = allPostCounts / ONE_PAGE_OF_DATA
            remainPost = allPostCounts % ONE_PAGE_OF_DATA
            if remainPost > 0:
                allPage += 1
    paginator = Paginator(resource1, 10)
    contacts = paginator.get_page(page)  # 当前页并具有处理超出页码范围的状况,页码不是数字返回第一页，超出返回最后一页

    # 使用了列表生成式，这样可以避免超出页码范围或出现页码数为负数的情况，另外我把page_list页码列表范围传出去，
    # 这样就可以在模板中使用了！另外添加了首尾页以及省略号！之后就是在模板中使用了！
    page_list = [x for x in range(contacts.number - 2, contacts.number + 3) if x in paginator.page_range]
    # 添加省略号
    # 判断当前第一个元素减1是否大于2
    if page_list[0] - 1 >= 2:
        page_list.insert(0, '...')  # 则插入该数组成为第一个元素 ...
    if paginator.num_pages - page_list[-1] >= 2:  # 判断最大页码数-最后一个元素相减是否大于2
        page_list.append('...')  # 则添加一个元素
    # 添加首尾页
    if page_list[0] == '...':
        page_list.insert(0, 1)  # 则插入该数组成为第一个元素（首页）
    if page_list[-1] != paginator.num_pages:  # 判断是否不等于最大页码
        page_list.append(paginator.num_pages)  # 不等于则插入到最后一个元素（尾页）
    context = {'posts':posts, 'allPage':allPage, 'curPage':cur_page,'contacts': contacts, 'page_list': page_list, 'needcheck': needcheck}
    return render(request, 'test_page.html', context=context)
def aboutUs(request):
    return render(request, 'aboutUs.html')

