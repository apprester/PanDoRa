function check_size(filesize) {
    // 如325462byte
    if (filesize === 0) return '0 B';
    var k = 1024, // or 1024
        sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(filesize) / Math.log(k));

   return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
}




//document.getElementById("check_size").innerHTML = check_size();

function check_time(datetime1) {
    return datetime1;
    // list1 = datetime1.toString().split(' ');
    // return list1[0];
}
//document.getElementById("change_time").innerHTML = check_time();