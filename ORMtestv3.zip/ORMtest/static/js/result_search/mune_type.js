$("#ch>li").click(function (e) {
		if ($(this).val()==1){
			$("#ch>li").removeClass("li-style1");
			$("#li-1").addClass("li-style1");
		}else if ($(this).val()==2){
			$("#ch>li").removeClass("li-style1");
			$("#li-2").addClass("li-style1");
		}else if ($(this).val()==3){
			$("#ch>li").removeClass("li-style1");
			$("#li-3").addClass("li-style1");
		}else if ($(this).val()==4){
			$("#ch>li").removeClass("li-style1");
			$("#li-4").addClass("li-style1");
		}else if ($(this).val()==5){
			$("#ch>li").removeClass("li-style1");
			$("#li-5").addClass("li-style1");
		}else if ($(this).val()==6){
			$("#ch>li").removeClass("li-style1");
			$("#li-6").addClass("li-style1");
		}
	});