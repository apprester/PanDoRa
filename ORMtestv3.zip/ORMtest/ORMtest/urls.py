"""ORMtest URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path
from book import views
from book.views import SearchSuggest, SearchResult

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='main'),
    path('search/', SearchResult.as_view(), name='request'),
    path('suggest/', SearchSuggest.as_view(), name='suggest'),
    path('request/detail/<main_id>', views.detail, name='detail'),
    path('menu/<menu_id>/<needcheck_val>', views.menu, name='menu')
    # path('menu/<menu_id>', views.menu, name='menu'),
    # path('test/', views.test),
    # path('aboutUs/', views.aboutUs)
]
