from elasticsearch_dsl import DocType, Date, Nested, Boolean, \
    analyzer, Completion, Keyword, Text, Float, Integer

# 导入CustomAnalysis包，因为这个版本的dsl存在问题，所以要自定义这个包
from elasticsearch_dsl.analysis import CustomAnalyzer as _CustomAnalyzer

# 导入elasticsearch服务器连接包
from elasticsearch_dsl.connections import connections
connections.create_connection(hosts=['47.100.126.218'])

# 自定义这个类
class CustomAnalyzer(_CustomAnalyzer):
    def get_analysis_definition(self):
        return {}

ik_analyzer = CustomAnalyzer('ik_max_word', filter=["lowercase"])

class ElasticsearchModel(DocType):
    suggest = Completion(analyzer=ik_analyzer)
    id = Integer()
    url = Keyword()
    filename = Text(analyzer='ik_max_word')
    username = Keyword()
    fsize = Float()
    ctime = Date()
    gettime = Date()
    pwd = Keyword()
    avatar = Keyword()
    category = Keyword()
    path = Keyword()
    shareid = Keyword()
    uk = Keyword()
    isdir = Integer()
    resume = Text(analyzer='ik_max_word')
    dir_context = Text(analyzer='ik_max_word')

    class Meta:
        index = 'pandora'
        doc_type = 'pandora_type'


if __name__ == '__main__':
    ElasticsearchModel.init()