from django.shortcuts import render
from book.models import ElasticsearchModel
from django.core.paginator import Paginator
from django.views.generic.base import View
from django.http import HttpResponse
import json
import re

from elasticsearch import Elasticsearch
client = Elasticsearch(hosts=["47.100.126.218"])

# 首页
def index(request):
    return render(request, 'home.html')

# 详细结果页
def detail(request, main_id):
    kb = 1024
    mb = kb * 1024
    gb = mb * 1024
    tb = gb * 1024
    response = client.search(
        index="pandora",
        body={
            "query": {
                "match": {
                    "id": main_id
                }
            },
            "from": 0,
            "size": 2
        }
    )
    main_res = response["hits"]["hits"]
    main_list = []
    for main_format in main_res:
        main_dirt = {}
        main_dirt["id"] = main_format["_source"]["id"]
        main_dirt["filename"] = main_format["_source"]["filename"]
        main_dirt["url"] = main_format["_source"]["url"]
        main_dirt["username"] = main_format["_source"]["username"]
        if int(main_format["_source"]["fsize"]) > tb:
            main_dirt["fsize"] = '%.2f TB' % float(int(main_format["_source"]["fsize"]) / tb)

        elif tb >= int(main_format["_source"]["fsize"]) > gb:
            main_dirt["fsize"] = '%.2f GB' % float(int(main_format["_source"]["fsize"]) / gb)

        elif gb >= int(main_format["_source"]["fsize"]) > mb:
            main_dirt["fsize"] = '%.2f MB' % float(int(main_format["_source"]["fsize"]) / mb)

        elif mb >= int(main_format["_source"]["fsize"]) >= kb:
            main_dirt["fsize"] = '%.2f KB' % float(int(main_format["_source"]["fsize"]) / kb)

        else:
            main_dirt["fsize"] = '%.2f ' % float(main_format["_source"]["fsize"])

        a = re.split(r'-|T', main_format["_source"]["ctime"])
        main_dirt["ctime"] = '%s-%s-%s' % (a[0], a[1], a[2])
        main_dirt["pwd"] = main_format["_source"]["pwd"]
        main_dirt["avatar"] = main_format["_source"]["avatar"]
        main_dirt["path"] = main_format["_source"]["path"]
        if main_format['_source']['isdir'] == 0:
            context_list = ''
        elif main_format['_source']['isdir'] == 1:
            if main_format['_source']['dir_context'] != '[]':
                context_list = main_format['_source']['dir_context'][2:-2]
                context_list = context_list.split("', '")
            else:
                context_list = ''
        else:
            pass
        main_list.append(main_dirt)
    return render(request, 'message.html', context={'finally': main_list, 'context_list': context_list})

def menu(request, menu_id, needcheck_val):
    needcheck = needcheck_val
    page = request.GET.get("p", "1")
    try:
        page = int(page)
    except:
        page = 1
    quick_check = 0
    if menu_id == '1':
        quick_check = 1
    elif menu_id == '2':
        quick_check = 2
    elif menu_id == '3':
        quick_check = 3
    elif menu_id == '4':
        quick_check = 4
    elif menu_id == '5':
        quick_check = 5
    elif menu_id == '6':
        quick_check = 6
    elif menu_id == '7':
        quick_check = 7
    elif menu_id == '0':
        quick_check = 0
    else:
        pass
    kb = 1024
    mb = kb * 1024
    gb = mb * 1024
    tb = gb * 1024
    response = client.search(
        index="pandora",
        body={
            "query": {
                "bool":{
                    "must":{"match":{"filename": needcheck}},
                    "filter":{"match":{"category": quick_check}}
                }
            },
            "from": (page-1)*10,
            "size": 10
        }
    )
    result = response["hits"]["hits"]
    total_nums = response["hits"]["total"] #值是查询关键词后，返回一共有多少数据。
    number = total_nums
    if total_nums >= 10000:
        number = 10000
    if (page % 10) > 0 and number < 10000:
        page_nums = int(number / 10) + 1
    else:
        page_nums = int(number / 10)
    res_list = []
    for hit in result:
        res_dict = {}
        res_dict["id"] = hit["_source"]["id"]
        res_dict["filename"] = hit["_source"]["filename"]
        res_dict["url"] = hit["_source"]["url"]
        res_dict["username"] = hit["_source"]["username"]
        res_dict["fsize"] = hit["_source"]["fsize"]
        if int(hit["_source"]["fsize"]) > tb:
            res_dict["fsize"] = '%.2f TB' % float(int(res_dict["fsize"]) / tb)

        elif tb >= int(hit["_source"]["fsize"]) > gb:
            res_dict["fsize"] = '%.2f GB' % float(int(res_dict["fsize"]) / gb)

        elif gb >= int(hit["_source"]["fsize"]) > mb:
            res_dict["fsize"] = '%.2f MB' % float(int(res_dict["fsize"]) / mb)

        elif mb >= int(hit["_source"]["fsize"]) >= kb:
            res_dict["fsize"] = '%.2f KB' % float(int(res_dict["fsize"]) / kb)
        else:
            res_dict["fsize"] = '%.2f ' % float(hit["_source"]["fsize"])
        a = re.split(r'-|T', hit["_source"]["ctime"])
        b = re.split(r'-|T', hit["_source"]["gettime"])
        res_dict["ctime"] = '%s-%s-%s' % (a[0], a[1], a[2])
        res_dict["gettime"] = '%s-%s-%s' % (b[0], b[1], b[2])
        res_dict["avatar"] = hit["_source"]["avatar"]
        res_dict["category"] = hit["_source"]["category"]
        res_dict["path"] = hit["_source"]["path"]
        res_dict["shareid"] = hit["_source"]["shareid"]
        res_dict["uk"] = hit["_source"]["uk"]
        res_dict["resume"] = hit["_source"]["resume"]
        res_list.append(res_dict)

    page_list = [x for x in range(page - 2, page + 3) if 0 < x and x < page_nums]
    try:
        if page_list[0] - 1 >= 2:
            page_list.insert(0, "...")  # 则插入该数组成为第一个元素 ...
        if page_nums - page > 2:  # 最后一个元素 - 现在page数，相减是否大于2
            page_list.append('...')  # 则添加一个元素
        # 添加首尾页
        if page_list[0] == '...':
            page_list.insert(0, 1)  # 则插入该数组成为第一个元素（首页）
        if page != page_nums:  # 判断是否不等于最大页码
            page_list.append(page_nums)  # 不等于则插入到最后一个元素（尾页）
        if page_list[-1] == (page_nums - 1):
            page_list.append(page_nums)
    except:
        page_list = [1,]

    return render(request, 'result.html', context={"page":page,
                                                   "page_list":page_list,
                                                   "page_nums":page_nums,
                                                   "total_nums":total_nums,
                                                   "res_list": res_list,
                                                   'needcheck':needcheck,
                                                   'menutype':quick_check
                                                   }
                  )


# 搜索建议逻辑
class SearchSuggest(View):
    def get(self, request):
        key_words = request.GET.get('s', '')
        re_datas = []
        if key_words:
            s = ElasticsearchModel.search()
            s = s.suggest('my_suggest', key_words, completion={
                "field": "suggest", "fuzzy": {
                    "fuzziness": 2
                },
                "size": 6
            })
            suggestions = s.execute_suggest()
            for match in suggestions.my_suggest[0].options:
                source = match._source
                re_datas.append(source["filename"])
        else:
            pass
        return HttpResponse(json.dumps(re_datas), content_type="application/json")

# 搜索逻辑
class SearchResult(View):
    def get(self, request):
        kb = 1024
        mb = kb * 1024
        gb = mb * 1024
        tb = gb * 1024
        needcheck = request.GET.get('needcheck', '')
        page = request.GET.get("p","1")
        try:
            page = int(page)
        except:
            page = 1

        response = client.search(
            index="pandora",
            body={
                "query": {
                    "match": {
                        "filename": needcheck
                    }
                },
                "from": (page-1)*10,
                "size": 10
            }
        )
        total_nums = response["hits"]["total"]
        number = total_nums
        if total_nums >= 10000:
            number = 10000
        if (page % 10) > 0 and number < 10000:
            page_nums = int(number / 10) + 1
        else:
            page_nums = int(number / 10)
        result = response["hits"]["hits"]
        res_list = []
        for hit in result:
            res_dict = {}
            res_dict["id"] = hit["_source"]["id"]
            res_dict["filename"] = hit["_source"]["filename"]
            res_dict["url"] = hit["_source"]["url"]
            res_dict["username"] = hit["_source"]["username"]
            res_dict["fsize"] = hit["_source"]["fsize"]
            if int(hit["_source"]["fsize"]) > tb:
                res_dict["fsize"] = '%.2f TB' % float(int(res_dict["fsize"]) / tb)

            elif tb >= int(hit["_source"]["fsize"]) > gb:
                res_dict["fsize"] = '%.2f GB' % float(int(res_dict["fsize"]) / gb)

            elif gb >= int(hit["_source"]["fsize"]) > mb:
                res_dict["fsize"] = '%.2f MB' % float(int(res_dict["fsize"]) / mb)

            elif mb >= int(hit["_source"]["fsize"]) >= kb:
                res_dict["fsize"] = '%.2f KB' % float(int(res_dict["fsize"]) / kb)
            else:
                res_dict["fsize"] = '%.2f ' % float(hit["_source"]["fsize"])
            a = re.split(r'-|T', hit["_source"]["ctime"])
            b = re.split(r'-|T', hit["_source"]["gettime"])
            res_dict["ctime"] = '%s-%s-%s' %(a[0], a[1], a[2])
            res_dict["gettime"] = '%s-%s-%s' %(b[0], b[1], b[2])
            res_dict["avatar"] = hit["_source"]["avatar"]
            res_dict["category"] = hit["_source"]["category"]
            res_dict["path"] = hit["_source"]["path"]
            res_dict["shareid"] = hit["_source"]["shareid"]
            res_dict["uk"] = hit["_source"]["uk"]
            res_dict["resume"] = hit["_source"]["resume"]
            res_list.append(res_dict)

        #还是熟悉的代码好，好弄。
        page_list = [x for x in range(page - 2, page + 3) if  0<x and x<page_nums]
        try:
            if page_list[0] - 1 >= 2:
                page_list.insert(0, "...")  # 则插入该数组成为第一个元素 ...
            if page_nums - page > 2:  # 最后一个元素 - 现在page数，相减是否大于2
                page_list.append('...')  # 则添加一个元素
            # 添加首尾页
            if page_list[0] == '...':
                page_list.insert(0, 1)  # 则插入该数组成为第一个元素（首页）
            if page != page_nums:  # 判断是否不等于最大页码
                page_list.append(page_nums)  # 不等于则插入到最后一个元素（尾页）
            if page_list[-1] == (page_nums - 1):
                page_list.append(page_nums)
        except:
            page_list = [1,]

        return render(request, "result.html", context={"page":page,
                                                       "page_list":page_list,
                                                       "page_nums":page_nums,
                                                       "total_nums":total_nums,
                                                       "res_list": res_list,
                                                       'needcheck':needcheck
                                                       }
                      )